export type ProductType =
  | "PREBUILT_PC"
  | "CPU"
  | "GPU"
  | "RAM"
  | "MOTHERBOARD"
  | "STORAGE"
  | "PSU"
  | "CASE"
  | "COOLING"
  | "MONITOR"
  | "KEYBOARD"
  | "MOUSE"
  | "HEADSET";
export type PeripheralType = "MONITOR" | "KEYBOARD" | "MOUSE" | "HEADSET";
export type ShoppingIntent = "PREBUILT_PC" | "CUSTOM_PC" | "UPGRADE_PC" | "COMPONENT" | "PC_WITH_PERIPHERALS";
export type BuilderMode = "GUIDED" | "AUTO";
export type ConversationStage = "DISCOVER_INTENT" | "DISCOVER_USE" | "DISCOVER_BUDGET" | "DISCOVER_DETAILS" | "RECOMMENDING" | "BUILDER_MODE" | "BUILDER" | "UPGRADE" | "COMPONENT" | "COMPLETE";
export type AwaitingField = "INTENT" | "USE" | "CONNECTIVITY" | "GAMING_TARGET" | "DEVELOPMENT_LOAD" | "BUDGET" | "BUILDER_MODE" | "COMPONENT_SELECTION" | null;
export type QuickReplyKind = "SET_INTENT" | "SET_BUDGET" | "SET_WORKLOAD" | "SET_CONNECTIVITY" | "SET_GAMING_TARGET" | "SET_DEVELOPMENT_LOAD" | "SET_BUILDER_MODE" | "BUILDER_ACTION" | "SEND_MESSAGE";
export interface QuickReply { id: string; label: string; kind: QuickReplyKind; value?: string | number; payload?: Record<string, unknown>; }
export interface BuilderFlow {
  mode: BuilderMode;
  currentStep: ProductType | "PERIPHERALS" | "ASSEMBLY" | "DONE";
  currentStepLabel?: string;
  previousStep?: ProductType | "PERIPHERALS" | "ASSEMBLY" | "DONE";
  editingStep?: ProductType | "PERIPHERALS" | "ASSEMBLY" | "DONE";
  completedSteps?: ProductType[];
  progress?: number;
  totalSteps?: number;
}

export interface Product {
  id: number;
  name: string;
  slug: string;
  description: string;
  price: number;
  stock: number;
  imageUrl: string;
  active: boolean;
  type: ProductType;
  cpu: string | null;
  gpu: string | null;
  ramGb: number | null;
  storageGb: number | null;
  vramGb: number | null;
  cpuScore: number | null;
  gpuScore: number | null;
  productivityScore: number | null;
  upgradeabilityScore: number | null;
  features: string[];
  technicalSpecs: Record<string, string | number | boolean | string[]>;
  createdAt: string;
  updatedAt: string;
}

export interface Workload {
  id: number;
  slug: string;
  name: string;
  type: string;
  description: string;
  cpuWeight: number;
  gpuWeight: number;
  ramWeight: number;
  storageWeight: number;
  vramWeight: number;
  minimumCpuScore: number;
  recommendedCpuScore: number;
  minimumGpuScore: number;
  recommendedGpuScore: number;
  minimumRamGb: number;
  recommendedRamGb: number;
  minimumVramGb: number;
  recommendedVramGb: number;
}

export interface RecommendationFilters {
  budgetMax?: number;
  budget?: number;
  budgetPreferred?: number;
  resolution?: "1080p" | "1440p" | "4k";
  targetFps?: number;
  workloads?: Array<{ slug: string; importance: number }>;
  preferences?: { futureUpgrade?: boolean; wifiRequired?: boolean; valuePriority?: boolean; multitaskingLevel?: "LIGHT" | "NORMAL" | "HEAVY" };
  requestedComponent?: ProductType;
}
export interface ConversationCriteria extends RecommendationFilters {
  intent?: ShoppingIntent | string;
  budget?: number;
  preferences?: RecommendationFilters["preferences"] & {
    wifiRequired?: boolean;
    valuePriority?: boolean;
    multitaskingLevel?: "LIGHT" | "NORMAL" | "HEAVY";
  };
}

export interface WorkloadScore {
  slug: string;
  workload: string;
  score: number;
  cpuFit: number;
  gpuFit: number;
  ramFit: number;
  vramFit: number;
  storageFit: number;
}

export interface Recommendation {
  category: "BEST_MATCH" | "BEST_VALUE" | "BUDGET_OPTION" | "PREMIUM_OPTION";
  categoryLabel: string;
  product: Product;
  fitScore: number;
  performanceFit: number;
  budgetFit: number;
  valueFit: number;
  upgradeabilityFit: number;
  workloadScores: WorkloadScore[];
  strengths: string[];
  weaknesses: string[];
}

export interface ChatResponse {
  message: string;
  needsMoreInformation: boolean;
  filters: RecommendationFilters | null;
  recommendations: Recommendation[];
  shoppingIntent?: ShoppingIntent;
  componentRecommendations?: Array<ComponentCandidate | Product>;
  componentType?: string;
  currentPc?: CurrentPc;
  upgradeGoal?: string | null;
  systemInfoGuide?: SystemInfoGuide;
  upgradeRecommendations?: Product[];
  peripheralRecommendations?: Product[];
  build?: BuildSummary;
  actions?: AssistantAction[];
  criteria?: ConversationCriteria;
  quickReplies?: QuickReply[];
  quickActions?: string[];
  stage?: ConversationStage;
  awaiting?: AwaitingField;
  debug?: { aiUsed: boolean; operation: string; stage: ConversationStage };
  warnings?: string[];
  upgradeAnalysis?: UpgradeAnalysis;
  flow?: BuilderFlow;
  lastRecommendedProductSlug?: string;
  lastComparedProductSlugs?: string[];
  lastBuilderAdviceTopic?: string;
  builderPreference?: "balanced" | "cheaper" | "powerful";
}

export interface ComponentCandidate {
  product: Product;
  recommendedRole?: "RECOMMENDED" | "BEST_VALUE" | "BUDGET" | "PREMIUM";
  rationale?: string;
  compatibility?: "COMPATIBLE" | "INCOMPATIBLE" | "UNKNOWN";
  compatibilityReasons?: string[];
  recommendationScore?: number;
  budgetImpact?: number;
  strengths?: string[];
  weaknesses?: string[];
}

export interface CurrentPc {
  cpu: string | null;
  gpu: string | null;
  ramGb: number | null;
  motherboard?: string | null;
  storage?: string | null;
  psuW?: number | null;
}

export interface SystemInfoGuide {
  title: string;
  command: string;
  steps: string[];
  note: string;
}

export interface BuildSummary {
  products: Product[];
  components: Product[];
  peripherals: Product[];
  subtotal: number;
  assembly: number;
  total: number;
  budgetRemaining: number | null;
  assemblyEnabled: boolean;
  complete: boolean;
  warnings: string[];
  compatibilityIssues?: CompatibilityIssue[];
  compatible: boolean;
  compatibility?: "COMPATIBLE" | "INCOMPATIBLE" | "UNKNOWN";
}

export interface CompatibilityIssue {
  code: string;
  severity: "INFO" | "WARNING" | "ERROR";
  message: string;
}

export interface AssistantAction {
  action: string;
  productId?: number;
  productSlug?: string;
  componentType?: ProductType;
  label?: string;
}

export interface UpgradeAnalysis {
  currentPc: CurrentPc;
  goal: string;
  detectedScores: { cpu: number | null; gpu: number | null; ramGb: number | null };
  priority: ProductType;
  bottleneck: string;
  assessment: string;
  compatibilityChecks: Array<{ status: string; label: string; detail: string }>;
  bestFirstUpgrade: Product | null;
  bestValue: Product | null;
  premium: Product | null;
  noNeedToChange: string;
  recommendations: Product[];
}
