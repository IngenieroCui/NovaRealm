"use client";

import Image from "next/image";
import Link from "next/link";
import { FormEvent, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { apiFetch, formatMoney, PRODUCT_TYPE_LABELS } from "@/lib/api";
import { useNova, type NovaSession } from "@/lib/nova-context";
import type { AssistantAction, BuildSummary, BuilderFlow, ChatResponse, ComponentCandidate, Product, ProductType, QuickReply, Recommendation, RecommendationFilters, ShoppingIntent, SystemInfoGuide } from "@/lib/types";
import { RecommendationCard } from "./recommendation-card";
import { WhatsAppBuyButton } from "./whatsapp-buy-button";

interface ChatMessage { id: number; role: "user" | "assistant"; content: string; recommendations?: Recommendation[]; componentRecommendations?: ComponentCandidate[]; build?: BuildSummary; flow?: BuilderFlow; currentPc?: ChatResponse["currentPc"]; actions?: AssistantAction[]; quickReplies?: QuickReply[]; upgradeAnalysis?: ChatResponse["upgradeAnalysis"]; systemInfoGuide?: SystemInfoGuide; actionableConsumed?: boolean; }
type RequestError = { kind: "start" | "chat" | "action"; message: string; retryText?: string; retryReply?: QuickReply; retryAction?: AssistantAction };

const suggestions = ["Tengo 5 millones. Juego Warzone y Valorant a 1440p y uso Blender.", "Quiero el PC más barato que sirva para Valorant. Máximo 3 millones.", "Uso Docker y máquinas virtuales. Mi presupuesto es 4.5 millones."];
const intentLabels: Record<ShoppingIntent, string> = { PREBUILT_PC: "PC completo", CUSTOM_PC: "Armar mi PC", UPGRADE_PC: "Mejorar mi PC", COMPONENT: "Un componente", PC_WITH_PERIPHERALS: "PC + periféricos" };
const roleLabels: Record<NonNullable<ComponentCandidate["recommendedRole"]>, string> = { RECOMMENDED: "Recomendada por Nova", BEST_VALUE: "Mejor valor", BUDGET: "Más económica", PREMIUM: "Más completa" };
const fallbackImages: Record<string, string> = { CPU: "/products/fallback/cpu.svg", GPU: "/products/fallback/gpu.svg", RAM: "/products/fallback/ram.svg", MOTHERBOARD: "/products/fallback/motherboard.svg", STORAGE: "/products/fallback/storage.svg", PSU: "/products/fallback/psu.svg", COOLING: "/products/fallback/cooling.svg", CASE: "/products/fallback/case.svg" };

export function NovaChat({ compact = false, context }: { compact?: boolean; context?: NovaSession }) {
  const searchParams = useSearchParams();
  const nova = useNova();
  const activeContext = context ?? nova.session;
  const startRequested = useRef(false);
  const querySent = useRef(false);
  const nextId = useRef(1);
  const requestBusy = useRef(false);
  const actionBusy = useRef(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [started, setStarted] = useState(false);
  const [filters, setFilters] = useState<RecommendationFilters | null>(activeContext.criteria ?? activeContext.filters);
  const [selected, setSelected] = useState<string[]>([]);
  const [requestError, setRequestError] = useState<RequestError | null>(null);

  const appendResponse = useCallback((response: ChatResponse, userContent?: string) => {
    const criteria = response.criteria ?? response.filters;
    if (criteria) setFilters(criteria);
    if (response.message || response.quickReplies?.length || response.quickActions?.length || response.componentRecommendations?.length || response.flow || response.build) setMessages((current) => [...current, responseMessage(response, nextId.current++)]);
    const changedIntent = response.shoppingIntent && response.shoppingIntent !== activeContext.shoppingIntent;
    nova.patchSession({
      ...(criteria ? { filters: criteria, criteria } : {}), shoppingIntent: response.shoppingIntent ?? activeContext.shoppingIntent,
      ...(changedIntent ? { selectedComponentType: undefined, builderMode: undefined, builderFlow: undefined, currentPc: undefined, upgradeGoal: undefined, lastRecommendedProductSlug: undefined, lastComparedProductSlugs: undefined, lastBuilderAdviceTopic: undefined, builderPreference: undefined } : {}),
      ...(response.componentType ? { selectedComponentType: response.componentType as ProductType } : {}), ...(response.currentPc ? { currentPc: response.currentPc } : {}), ...(response.upgradeGoal ? { upgradeGoal: response.upgradeGoal } : {}),
      ...(response.build ? { currentBuild: response.build.products.filter((product) => product.type !== "PREBUILT_PC").map((product) => product.slug), assemblySelected: response.build.assembly > 0 } : {}), ...(response.flow ? { builderFlow: response.flow, builderMode: response.flow.mode } : {}),
      lastRecommendedProductSlug: response.lastRecommendedProductSlug, lastComparedProductSlugs: response.lastComparedProductSlugs, lastBuilderAdviceTopic: response.lastBuilderAdviceTopic, builderPreference: response.builderPreference,
      conversation: userContent ? [...activeContext.conversation, { role: "user", content: userContent }, { role: "assistant", content: response.message }] : [...activeContext.conversation, { role: "assistant", content: response.message }],
    });
  }, [activeContext, nova]);

  const startNova = useCallback(async (force = false) => {
    if (startRequested.current && !force) return;
    startRequested.current = true; requestBusy.current = true; setLoading(true); setRequestError(null);
    try {
      const response = await apiFetch<ChatResponse>("/assistant/start", { method: "POST", body: JSON.stringify({ ...(filters ? { criteria: filters } : {}), context: assistantContext(activeContext) }) });
      appendResponse(response); setStarted(true);
    } catch (reason) {
      setRequestError({ kind: "start", message: reason instanceof Error ? reason.message : "Intenta nuevamente." });
    } finally { requestBusy.current = false; setLoading(false); }
  }, [activeContext, appendResponse, filters]);

  const send = useCallback(async (requestText: string, showUser = true, quickReply?: QuickReply, displayText = requestText) => {
    const clean = requestText.trim();
    if (!clean || requestBusy.current) return;
    requestBusy.current = true; setRequestError(null);
    const history = messages.slice(-8).map(({ role, content }) => ({ role, content }));
    if (showUser) setMessages((current) => [...current.map((message) => hasActionables(message) ? { ...message, actionableConsumed: true } : message), { id: nextId.current++, role: "user", content: displayText.trim() }]);
    setInput(""); setLoading(true);
    try {
      const response = await apiFetch<ChatResponse>("/assistant/chat", { method: "POST", body: JSON.stringify({ message: clean, conversation: history, ...(filters ? { criteria: filters } : {}), ...(quickReply ? { quickReply } : {}), ...(activeContext.shoppingIntent ? { shoppingIntent: activeContext.shoppingIntent } : {}), context: assistantContext(activeContext) }) });
      setSelected([]); appendResponse(response, showUser ? displayText.trim() : undefined);
    } catch (reason) {
      setRequestError({ kind: "chat", message: reason instanceof Error ? reason.message : "Intenta nuevamente.", retryText: clean, retryReply: quickReply });
    } finally { requestBusy.current = false; setLoading(false); }
  }, [activeContext, appendResponse, filters, messages]);

  const applyAction = useCallback(async (action: AssistantAction, messageId?: number) => {
    if (actionBusy.current || requestBusy.current) return;
    actionBusy.current = true; setRequestError(null);
    if (messageId) setMessages((current) => current.map((message) => message.id === messageId ? { ...message, actionableConsumed: true } : message));
    setLoading(true);
    try {
      const payload = { action: action.action, currentSlugs: activeContext.currentBuild, ...(action.productSlug ? { productSlug: action.productSlug } : {}), ...(action.productId ? { productId: action.productId } : {}), ...(action.componentType ? { componentType: action.componentType } : {}), ...(filters?.budgetMax ? { budgetMax: filters.budgetMax } : {}), ...(filters?.workloads ? { workloads: filters.workloads } : {}), ...(activeContext.builderMode ? { mode: activeContext.builderMode } : {}), assemblySelected: activeContext.assemblySelected };
      const response = await apiFetch<ChatResponse>("/assistant/action", { method: "POST", body: JSON.stringify({ builderAction: payload, ...(filters ? { criteria: filters } : {}), context: assistantContext(activeContext), conversation: activeContext.conversation.slice(-8) }) });
      appendResponse(response, action.label ?? action.action);
    } catch (reason) {
      setRequestError({ kind: "action", message: reason instanceof Error ? reason.message : "No pude aplicar ese cambio a la configuración.", retryAction: action });
    } finally { actionBusy.current = false; setLoading(false); }
  }, [activeContext, appendResponse, filters]);

  const handleQuickReply = useCallback((reply: QuickReply, messageId: number) => {
    if (reply.kind === "BUILDER_ACTION") {
      const action = typeof reply.payload?.action === "string" ? reply.payload.action : "";
      if (action) void applyAction({ action, componentType: typeof reply.payload?.componentType === "string" ? reply.payload.componentType as ProductType : undefined, label: reply.label }, messageId);
      return;
    }
    setMessages((current) => current.map((message) => message.id === messageId ? { ...message, actionableConsumed: true } : message));
    const value = reply.value === undefined ? reply.label : String(reply.value);
    const requestText = reply.kind === "SEND_MESSAGE" ? value : `${reply.kind}:${value}`;
    void send(requestText, true, reply, reply.label);
  }, [applyAction, send]);

  useEffect(() => { if (!startRequested.current) void startNova(); }, [startNova]);
  useEffect(() => { const query = searchParams.get("q"); if (started && query && !querySent.current) { querySent.current = true; void send(query); } }, [searchParams, send, started]);

  const available = useMemo(() => { const map = new Map<string, Recommendation>(); messages.forEach((message) => message.recommendations?.forEach((item) => map.set(item.product.slug, item))); return [...map.values()]; }, [messages]);
  const selectedRecommendations = available.filter((item) => selected.includes(item.product.slug));
  const lastActionableId = [...messages].reverse().find(hasActionables)?.id;
  const standaloneShopping = activeContext.shoppingIntent === "COMPONENT";
  function toggle(slug: string) { setSelected((current) => current.includes(slug) ? current.filter((item) => item !== slug) : current.length < 3 ? [...current, slug] : current); }
  function submit(event: FormEvent) { event.preventDefault(); void send(input); }

  return <div className={compact ? "nova-chat nova-chat-compact" : "nova-page"}>
    {!compact && <section className="nova-intro"><div className="nova-avatar" aria-hidden="true">N</div><div><span className="eyebrow">ASISTENTE DE COMPRA</span><h1>Hablemos de tu próximo computador.</h1><p>Productos reales y recomendaciones claras para decidir.</p></div></section>}
    <div className={compact ? "nova-chat-inner" : "nova-shell"}>
      <section className="chat-panel">
        <div className="chat-status"><span><i /> Nova en línea</span><small>Precios, stock y compatibilidad salen del backend.</small></div>
        <div className="messages" aria-live="polite">
          {messages.map((message) => <div key={message.id} className={`message-row ${message.role}`}>
            {message.role === "assistant" && <div className="mini-avatar" aria-hidden="true">N</div>}
            <div className="message-content"><MarkdownMessage content={message.content} />
              {message.flow ? <BuilderProgress flow={message.flow} disabled={loading || message.actionableConsumed || lastActionableId !== message.id} onPrevious={() => void applyAction({ action: "GO_TO_STEP", componentType: message.flow?.previousStep as ProductType, label: "Anterior" }, message.id)} /> : null}
              {message.actions?.length ? <div className="nova-action-chips">{message.actions.map((action) => <button key={`${action.action}-${action.productSlug ?? action.componentType ?? ""}`} onClick={() => void applyAction(action, message.id)} disabled={loading || message.actionableConsumed || lastActionableId !== message.id}>{action.label ?? action.action}</button>)}</div> : null}
              {message.quickReplies?.length ? <div className="nova-action-chips">{message.quickReplies.map((reply) => <button key={reply.id} onClick={() => handleQuickReply(reply, message.id)} disabled={loading || message.actionableConsumed || lastActionableId !== message.id}>{reply.label}</button>)}</div> : null}
              {message.recommendations?.length ? <div className="recommendations-grid">{message.recommendations.map((item) => <RecommendationCard key={item.product.slug} recommendation={item} selected={selected.includes(item.product.slug)} onToggle={() => toggle(item.product.slug)} />)}</div> : null}
              {message.componentRecommendations?.length ? <div className="component-recommendations">{message.componentRecommendations.map((candidate) => <ComponentRecommendation key={candidate.product.slug} candidate={candidate} standalone={standaloneShopping} disabled={loading || message.actionableConsumed || lastActionableId !== message.id} onChoose={() => void applyAction({ action: "ADD_TO_BUILD", productSlug: candidate.product.slug }, message.id)} />)}</div> : null}
              {message.currentPc ? <div className="current-pc"><span>PC ACTUAL</span><strong>{message.currentPc.cpu ?? "CPU por confirmar"}</strong><strong>{message.currentPc.gpu ?? "GPU por confirmar"}</strong>{message.currentPc.ramGb ? <strong>{message.currentPc.ramGb} GB RAM</strong> : null}</div> : null}
              {message.systemInfoGuide ? <SystemInfoCard guide={message.systemInfoGuide} /> : null}
              {message.upgradeAnalysis ? <UpgradePanel analysis={message.upgradeAnalysis} /> : null}
              {message.build ? <BuildPanel build={message.build} guided={message.flow?.mode === "GUIDED" || activeContext.builderMode === "GUIDED"} disabled={loading || message.actionableConsumed || lastActionableId !== message.id} onChange={(componentType) => void applyAction({ action: "GO_TO_STEP", componentType, label: `Cambiar ${componentLabel(componentType)}` }, message.id)} /> : null}
            </div>
          </div>)}
          {loading && <div className="message-row assistant"><div className="mini-avatar" aria-hidden="true">N</div><div className="message-bubble typing"><i /><i /><i /><span>Nova está revisando el catálogo</span></div></div>}
          {requestError && <div className="connection-error" role="alert"><div className="connection-error-card"><strong>{requestError.kind === "start" ? "No pude conectarme con Nova." : requestError.kind === "action" ? "No pude completar ese cambio." : "No pude completar la solicitud."}</strong><p>{requestError.message}</p><button onClick={() => { const error = requestError; if (error.kind === "start") { startRequested.current = false; void startNova(true); } else if (error.kind === "action" && error.retryAction) void applyAction(error.retryAction); else if (error.retryText) void send(error.retryText, false, error.retryReply); }} disabled={loading}>Reintentar</button></div></div>}
        </div>
        {messages.length === 0 && !loading && <div className="chat-suggestions">{suggestions.map((suggestion) => <button key={suggestion} onClick={() => void send(suggestion)}>{suggestion}<span>→</span></button>)}</div>}
        <form className="chat-composer" onSubmit={submit}><textarea rows={2} maxLength={2000} value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); void send(input); } }} placeholder="Ej: Quiero una GPU para jugar a 1440p…" /><button type="submit" disabled={!input.trim() || loading} aria-label="Enviar mensaje">↑</button><small>Enter para enviar · Shift + Enter para nueva línea</small></form>
      </section>
      {!compact && <CriteriaPanel criteria={filters} intent={activeContext.shoppingIntent} />}
    </div>
    {selectedRecommendations.length > 0 && !compact && <section className="comparison-dock shell"><div className="comparison-heading"><div><span className="eyebrow">COMPARADOR</span><h2>{selectedRecommendations.length} equipos seleccionados</h2></div><button onClick={() => setSelected([])}>Limpiar</button></div><div className="comparison-purchase-actions">{selectedRecommendations.map((item) => <WhatsAppBuyButton key={item.product.slug} className="comparison-buy-button" productName={item.product.name} price={item.product.price} fitScore={item.fitScore} />)}</div></section>}
  </div>;
}

function assistantContext(context: NovaSession) { return { page: typeof window !== "undefined" ? window.location.pathname : undefined, productSlug: context.selectedProduct?.slug, buildSlugs: context.currentBuild, selectedComponentType: context.selectedComponentType, shoppingIntent: context.shoppingIntent, builderMode: context.builderMode, builderStep: context.builderFlow?.currentStep, assemblySelected: context.assemblySelected, currentPc: context.currentPc, upgradeGoal: context.upgradeGoal, lastRecommendedProductSlug: context.lastRecommendedProductSlug, lastComparedProductSlugs: context.lastComparedProductSlugs, lastBuilderAdviceTopic: context.lastBuilderAdviceTopic, builderPreference: context.builderPreference }; }
function responseMessage(response: ChatResponse, id: number): ChatMessage { return { id, role: "assistant", content: response.message ?? "", recommendations: response.recommendations, componentRecommendations: normalizeComponentCandidates([...(response.componentRecommendations ?? []), ...(response.upgradeRecommendations ?? []), ...(response.peripheralRecommendations ?? [])]), currentPc: response.currentPc, build: response.build, flow: response.flow, actions: response.actions, quickReplies: normalizeQuickReplies(response), upgradeAnalysis: response.upgradeAnalysis, systemInfoGuide: response.systemInfoGuide }; }
function normalizeQuickReplies(response: ChatResponse): QuickReply[] { const structured = Array.isArray(response.quickReplies) ? response.quickReplies.filter((reply) => reply && typeof reply.id === "string" && typeof reply.label === "string") : []; if (structured.length) return structured; return (response.quickActions ?? []).filter((action) => typeof action === "string" && action.trim()).map((action, index) => ({ id: `legacy-${index}-${action}`, label: action, kind: "SEND_MESSAGE", value: action })); }
function normalizeComponentCandidates(items: Array<ComponentCandidate | Product>): ComponentCandidate[] { return items.flatMap((item) => { if (!item || typeof item !== "object") return []; const raw = item as ComponentCandidate & Product; const product = raw.product && typeof raw.product === "object" ? raw.product : raw as Product; if (!product.slug || !product.name) return []; return [{ product: normalizeProduct(product), recommendedRole: raw.recommendedRole, rationale: raw.rationale, compatibility: raw.compatibility, compatibilityReasons: raw.compatibilityReasons, recommendationScore: raw.recommendationScore, budgetImpact: raw.budgetImpact, strengths: raw.strengths, weaknesses: raw.weaknesses }]; }); }
function normalizeProduct(product: Product): Product { return { ...product, description: product.description ?? "", imageUrl: product.imageUrl ?? "", features: Array.isArray(product.features) ? product.features : [], technicalSpecs: product.technicalSpecs ?? {} }; }
function hasActionables(message: ChatMessage) { return Boolean(message.actions?.length || message.quickReplies?.length || message.componentRecommendations?.length || message.flow?.previousStep || message.build); }
function componentLabel(type: string) { return ({ CPU: "Procesador", GPU: "Tarjeta gráfica", RAM: "Memoria RAM", MOTHERBOARD: "Motherboard", STORAGE: "Almacenamiento", PSU: "Fuente", COOLING: "Refrigeración", CASE: "Chasis", PERIPHERALS: "Periféricos", ASSEMBLY: "Ensamble", DONE: "Configuración" } as Record<string, string>)[type] ?? type; }

function ComponentRecommendation({ candidate, onChoose, disabled, standalone }: { candidate: ComponentCandidate; onChoose: () => void; disabled: boolean; standalone: boolean }) { const { product } = candidate; const specs = componentSpecs(product); return <article className="component-result"><div className="component-result-image"><ProductCandidateImage product={product} /><div className="component-result-copy">{candidate.recommendedRole ? <span className="component-role-badge">{roleLabels[candidate.recommendedRole]}</span> : null}<span className="type-chip">{componentLabel(product.type)}</span><h3>{product.name}</h3><p className="component-description">{product.description}</p>{candidate.rationale ? <p className="component-rationale">{candidate.rationale}</p> : null}<ul className="component-specs">{specs.map((spec) => <li key={spec}>{spec}</li>)}</ul></div></div><div className="component-result-actions"><strong>{formatMoney(product.price)}</strong><div><button className="button button-small button-dark" onClick={onChoose} disabled={disabled}>{standalone ? "Agregar" : "Elegir"}</button><Link className="button button-small button-outline" href={`/productos/${product.slug}`}>Ver detalle</Link>{standalone ? <WhatsAppBuyButton className="whatsapp-buy-button-compact" productName={product.name} price={product.price} /> : null}</div></div></article>; }
function ProductCandidateImage({ product }: { product: Product }) { const fallback = fallbackImages[product.type] ?? "/products/fallback/peripheral.svg"; const [src, setSrc] = useState(product.imageUrl || fallback); return <div className="component-result-media"><Image src={src} alt={`${product.name} — ${componentLabel(product.type)}`} width={88} height={88} unoptimized onError={() => setSrc(fallback)} /></div>; }

export function componentSpecs(product: Product): string[] { const specs = product.technicalSpecs ?? {}; const value = (...keys: string[]) => keys.map((key) => specs[key]).find((item) => item !== undefined && item !== null && item !== ""); const display = (item: unknown) => Array.isArray(item) ? item.join(", ") : typeof item === "boolean" ? (item ? "Sí" : "No") : String(item); const result: string[] = []; const add = (label: string, item: unknown, suffix = "") => { if (item !== undefined && item !== null && item !== "") result.push(`${label}: ${display(item)}${suffix}`); }; if (product.type === "CPU") { add("Núcleos", value("cores", "coreCount")); add("Hilos", value("threads", "threadCount")); add("Socket", value("socket")); } if (product.type === "MOTHERBOARD") { add("Socket", value("socket")); add("RAM", value("ramType", "memoryType")); const wifi = value("wifi", "wifiSupported", "hasWifi"); if (wifi !== undefined) add("Wi‑Fi", wifi === false ? "Sin Wi‑Fi" : wifi === true ? "Sí" : wifi); } if (product.type === "RAM") { add("Capacidad", value("capacityGb") ?? product.ramGb, " GB"); add("Tipo", value("ramType", "memoryType")); const speed = value("speed", "speedMhz"); add("Velocidad", speed, typeof speed === "number" ? " MHz" : ""); } if (product.type === "GPU") { add("VRAM", value("vramGb") ?? product.vramGb, " GB"); add("Fuente recomendada", value("recommendedPsuWatts"), " W"); } if (product.type === "STORAGE") { add("Capacidad", value("capacityGb") ?? product.storageGb, " GB"); add("Interfaz", value("interface", "storageInterface")); const generation = value("generation", "pcieGeneration", "gen"); if (generation !== undefined) add("Generación", String(generation).toLowerCase().includes("4") ? "Gen4" : generation); } if (product.type === "PSU") { add("Potencia", value("wattage"), " W"); add("Eficiencia", value("efficiency", "efficiencyRating")); } if (product.type === "COOLING") add("TDP máximo", value("maxTdpW", "tdpW"), " W"); if (product.type === "CASE") add("Formatos", value("supportedFormFactors", "formFactors")); return result.slice(0, 3); }

function CriteriaPanel({ criteria, intent }: { criteria: RecommendationFilters | null; intent?: ShoppingIntent }) { const preferences = criteria?.preferences; const items: Array<{ label: string; value: string | string[] }> = []; if (intent) items.push({ label: "Uso", value: intentLabels[intent] }); const budget = criteria?.budgetMax ?? criteria?.budget; if (budget) items.push({ label: "Presupuesto máximo", value: formatMoney(budget) }); const workloads = criteria?.workloads?.map((item) => item.slug.replaceAll("-", " ")).filter(Boolean); if (workloads?.length) items.push({ label: "Usos principales", value: workloads }); if (preferences?.wifiRequired !== undefined) items.push({ label: "Conectividad", value: preferences.wifiRequired ? "Necesita Wi‑Fi" : "No requiere Wi‑Fi" }); if (preferences?.valuePriority !== undefined) items.push({ label: "Prioridad", value: preferences.valuePriority ? "Evitar gastos innecesarios" : "Priorizar rendimiento" }); if (preferences?.multitaskingLevel) items.push({ label: "Multitarea", value: ({ LIGHT: "Ligera", NORMAL: "Normal", HEAVY: "Intensa" } as Record<string, string>)[preferences.multitaskingLevel] }); if (criteria?.resolution) items.push({ label: "Resolución", value: criteria.resolution.toUpperCase() }); if (criteria?.targetFps) items.push({ label: "FPS objetivo", value: `${criteria.targetFps} FPS` }); return <aside className="criteria-panel"><div className="criteria-title"><span>⌁</span><div><h2>Lo que entendí</h2><p>Se actualiza con la conversación</p></div></div>{items.length ? <div className="criteria-list">{items.map((item) => <div key={item.label}><span>{item.label}</span>{Array.isArray(item.value) ? <div className="criteria-tags">{item.value.map((value) => <span key={value}>{value}</span>)}</div> : <strong>{item.value}</strong>}</div>)}</div> : <div className="criteria-empty"><span>✦</span><p>Cuéntame qué quieres hacer y te acompaño.</p></div>}<div className="privacy-note"><span>◇</span><p><strong>IA segura</strong>Nova no recibe datos sensibles; catálogo, stock, precios y compatibilidad salen del backend.</p></div></aside>; }

function SystemInfoCard({ guide }: { guide: SystemInfoGuide }) { const [copied, setCopied] = useState(false); async function copy() { await navigator.clipboard.writeText(guide.command); setCopied(true); window.setTimeout(() => setCopied(false), 1800); } return <section className="system-info-guide"><div className="system-info-heading"><div><span>WINDOWS · SOLO LECTURA</span><strong>{guide.title}</strong></div><button onClick={() => void copy()}>{copied ? "Copiado ✓" : "Copiar comando"}</button></div><pre><code>{guide.command}</code></pre><ol>{guide.steps.map((step) => <li key={step}>{step}</li>)}</ol><p>{guide.note}</p></section>; }
function UpgradePanel({ analysis }: { analysis: NonNullable<ChatResponse["upgradeAnalysis"]> }) { return <section className="upgrade-panel"><p className="upgrade-bottleneck"><b>Diagnóstico:</b> {analysis.bottleneck}</p><div><span>MEJOR PRIMER UPGRADE</span><strong>{analysis.bestFirstUpgrade?.name ?? "Por definir"}</strong></div><div><span>MEJOR PRECIO/RENDIMIENTO</span><strong>{analysis.bestValue?.name ?? "Por definir"}</strong></div><div><span>OPCIÓN PREMIUM</span><strong>{analysis.premium?.name ?? "Por definir"}</strong></div><p><b>Esto puede esperar:</b> {analysis.noNeedToChange}</p>{analysis.compatibilityChecks?.map((check) => <p className="upgrade-check" key={check.label}><b>{check.label}:</b> {check.detail}</p>)}</section>; }
function MarkdownMessage({ content }: { content: string }) { const blocks = content.trim().split(/\n\s*\n/).filter(Boolean); return <div className="message-bubble message-markdown">{blocks.map((block, index) => { const lines = block.split("\n"); const isList = lines.every((line) => /^\s*[-*]\s+/.test(line)); return isList ? <ul key={index}>{lines.map((line) => <li key={line}>{inlineMarkdown(line.replace(/^\s*[-*]\s+/, ""))}</li>)}</ul> : <p key={index}>{lines.map((line, lineIndex) => <span key={lineIndex}>{lineIndex ? <br /> : null}{inlineMarkdown(line)}</span>)}</p>; })}</div>; }
function inlineMarkdown(value: string) { const tokens = value.split(/(\*\*[^*]+\*\*|\[[^\]]+\]\([^\s)]+\))/g); return tokens.map((token, index) => { const bold = token.match(/^\*\*(.+)\*\*$/); const link = token.match(/^\[([^\]]+)\]\(([^\s)]+)\)$/); if (bold) return <strong key={index}>{bold[1]}</strong>; if (link && /^(https?:\/\/|\/)/i.test(link[2])) return <a key={index} href={link[2]} target={link[2].startsWith("http") ? "_blank" : undefined} rel={link[2].startsWith("http") ? "noreferrer" : undefined}>{link[1]}</a>; return <span key={index}>{token.replace(/[*_`]/g, "")}</span>; }); }
function BuilderProgress({ flow, disabled, onPrevious }: { flow: BuilderFlow; disabled: boolean; onPrevious: () => void }) { const total = flow.totalSteps ?? 0; const progress = Math.max(0, Math.min(100, flow.progress ?? 0)); if (flow.currentStep === "DONE") return <div className="builder-progress is-done"><strong>Configuración lista</strong><span>{progress}% completado</span></div>; return <div className="builder-progress"><div className="builder-progress-heading"><div><strong>Armando tu PC</strong><span>Paso {(flow.completedSteps?.length ?? 0) + 1} de {total || "—"} · {flow.currentStepLabel ?? componentLabel(flow.currentStep)}</span>{flow.editingStep ? <small>Revisando: {componentLabel(flow.editingStep)}</small> : null}</div>{flow.previousStep ? <button className="builder-previous" onClick={onPrevious} disabled={disabled}>← Anterior</button> : null}</div><div className="builder-progress-track" aria-label={`Progreso: ${progress}%`}><i style={{ width: `${progress}%` }} /></div></div>; }
function BuildPanel({ build, guided, disabled, onChange }: { build: BuildSummary; guided: boolean; disabled: boolean; onChange: (componentType: ProductType) => void }) { const group = (title: string, products: Product[]) => <div className="build-summary-group"><div className="build-summary-group-title">{title}</div>{products.length ? products.map((product) => <div className="build-line" key={product.slug}><span>{PRODUCT_TYPE_LABELS[product.type] ?? product.type}</span><strong>{product.name}</strong><span>{formatMoney(product.price)}</span>{guided ? <button className="build-change" onClick={() => onChange(product.type)} disabled={disabled}>Cambiar</button> : null}</div>) : <p className="summary-empty">Aún no hay productos.</p>}</div>; return <section className="build-panel"><div className="build-panel-heading"><div><span className="eyebrow">CONFIGURACIÓN ACTUAL</span><h3>{build.products.length ? "Tu PC por componentes" : "Aún no hay componentes"}</h3></div><strong>{formatMoney(build.total)}</strong></div>{group("Componentes", build.components)}{group("Periféricos", build.peripherals)}{build.assembly ? <div className="build-summary-group"><div className="build-summary-group-title">Servicios</div><div className="build-line"><span>Ensamble</span><strong>Entrega ensamblada</strong><span>{formatMoney(build.assembly)}</span></div></div> : null}<div className="build-total"><span>Total</span><strong>{formatMoney(build.total)}</strong></div><div className="budget-result"><span>Presupuesto restante</span><strong>{build.budgetRemaining === null ? "—" : formatMoney(build.budgetRemaining)}</strong></div><p className={`build-compatibility ${build.compatible ? "is-ok" : "is-error"}`}>{build.complete ? "✓ Configuración completa y compatible" : build.compatible ? "✓ Sin incompatibilidades detectadas hasta ahora" : `! Hay que corregir ${(build.compatibilityIssues ?? []).filter((item) => item.severity === "ERROR").length || 1} incompatibilidad`}</p>{(build.compatibilityIssues ?? []).filter((issue) => issue.severity === "ERROR").slice(0, 1).map((issue) => <p className="build-warning" key={issue.code}>{issue.message}</p>)}<WhatsAppBuyButton className="chat-build-quote" productName="configuración personalizada" price={build.total} buildLines={build.products.map((product) => `${PRODUCT_TYPE_LABELS[product.type] ?? product.type}: ${product.name} · ${formatMoney(product.price)}`)} assembly={Boolean(build.assembly)}>{build.products.length === 1 ? "Cotizar este producto" : "Cotizar por WhatsApp"}</WhatsAppBuyButton></section>; }
