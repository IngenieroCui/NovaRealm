import { Injectable } from '@nestjs/common';
import {
  ConversationCriteriaDto,
  ConversationStage,
  ShoppingIntent,
} from './assistant.dto';

export type DiscoveryQuestion =
  | 'INTENT'
  | 'USE'
  | 'CONNECTIVITY'
  | 'GAMING_TARGET'
  | 'DEVELOPMENT_LOAD'
  | 'BUDGET'
  | 'BUILDER_MODE';

export interface DiscoveryDecision {
  awaiting: DiscoveryQuestion;
  stage: ConversationStage;
  reason: string;
}

const GAME_WORKLOADS = new Set([
  'valorant',
  'league-of-legends',
  'fortnite',
  'warzone',
  'cyberpunk-2077',
  'minecraft',
  'gta-v',
  'apex-legends',
]);

@Injectable()
export class DiscoveryPolicyService {
  next(
    intent: ShoppingIntent | undefined,
    criteria: ConversationCriteriaDto,
  ): DiscoveryDecision | null {
    if (!intent) return this.decision('INTENT', ConversationStage.DISCOVER_INTENT, 'shopping intent is not known');

    const workloads = new Set((criteria.workloads ?? []).map((item) => item.slug));
    if ((intent === ShoppingIntent.PREBUILT_PC || intent === ShoppingIntent.CUSTOM_PC || intent === ShoppingIntent.PC_WITH_PERIPHERALS) && !workloads.size) {
      return this.decision('USE', ConversationStage.DISCOVER_USE, 'no meaningful workload is known');
    }

    if (intent === ShoppingIntent.CUSTOM_PC) {
      const preferences = criteria.preferences ?? {};
      if (workloads.has('ofimatica-basica') && preferences.wifiRequired === undefined) {
        return this.decision('CONNECTIVITY', ConversationStage.DISCOVER_DETAILS, 'office workload has unknown connectivity needs');
      }

      if (
        workloads.has('programacion') &&
        !workloads.has('docker') &&
        !workloads.has('maquinas-virtuales') &&
        preferences.multitaskingLevel === undefined
      ) {
        return this.decision('DEVELOPMENT_LOAD', ConversationStage.DISCOVER_DETAILS, 'programming workload has unknown development load');
      }

      if (
        [...workloads].some((slug) => GAME_WORKLOADS.has(slug)) &&
        (criteria.resolution === undefined || criteria.targetFps === undefined)
      ) {
        return this.decision('GAMING_TARGET', ConversationStage.DISCOVER_DETAILS, 'game workload has unknown resolution or target FPS');
      }
    }

    if (criteria.budgetMax === undefined) {
      return this.decision('BUDGET', ConversationStage.DISCOVER_BUDGET, 'maximum budget is not known');
    }

    if (intent === ShoppingIntent.CUSTOM_PC) {
      return this.decision('BUILDER_MODE', ConversationStage.BUILDER_MODE, 'custom build mode is not known');
    }

    return null;
  }

  private decision(
    awaiting: DiscoveryQuestion,
    stage: ConversationStage,
    reason: string,
  ): DiscoveryDecision {
    return { awaiting, stage, reason };
  }
}
